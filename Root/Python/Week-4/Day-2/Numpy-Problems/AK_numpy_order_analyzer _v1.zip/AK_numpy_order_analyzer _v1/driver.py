# driver.py
"""
Test driver for NumpyArrayAnalyzer (matrix-related tests removed).

Behavior:
- Static checks run but do NOT abort the test run. Issues are logged as warnings.
- Methods detected as pass-only / constant-return will cause their tests to FAIL with a clear reason,
  but they are not treated as anti-cheat aborts.
- Deterministic visible tests (23 cases — matrix tests removed) run and results are appended to test_report.log.
- Lightweight randomized sanity checks run and are reported as warnings (informational).
- Robust class-source extraction with fallback when inspect.getsource() fails.
"""

import os
import inspect
import importlib.util
import ast
from datetime import datetime
from types import ModuleType
from typing import Tuple, List, Optional

import numpy as np

ASSESSMENT_NAME = "NumPy Array Analysis"
LOG_FILE = "test_report.log"


def _log_line(message: str) -> None:
    print(message)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(message + "\n")


def _load_solution_module(solution_path: Optional[str]) -> ModuleType:
    if solution_path is None:
        import solution  # type: ignore
        return solution

    spec = importlib.util.spec_from_file_location("solution", solution_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load solution module from {solution_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[attr-defined]
    return module


def _get_class_source(module: ModuleType, class_name: str, solution_path: Optional[str] = None) -> str:
    cls = getattr(module, class_name, None)
    if cls is None:
        raise AttributeError(f"Class {class_name} not found in module {getattr(module, '__name__', '<module>')}")

    try:
        return inspect.getsource(cls)
    except (OSError, TypeError):
        src_file = getattr(module, "__file__", None) or solution_path
        if not src_file:
            raise TypeError(f"inspect.getsource failed for {class_name} and no source file available to read.")
        if os.path.isdir(src_file):
            raise TypeError(f"Module file path is a directory: {src_file}")
        try:
            with open(src_file, "r", encoding="utf-8") as f:
                full_src = f.read()
        except Exception as e:
            raise IOError(f"Failed to read source file {src_file}: {e}")

        try:
            tree = ast.parse(full_src)
        except SyntaxError as e:
            raise SyntaxError(f"Failed to parse {src_file}: {e}")

        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                try:
                    seg = ast.get_source_segment(full_src, node)
                    if seg:
                        return seg
                except Exception:
                    pass
                try:
                    return ast.unparse(node)
                except Exception as e:
                    raise RuntimeError(f"Could not extract class source for {class_name}: {e}")

        raise AttributeError(f"Class {class_name} not found in source file {src_file}")


REQUIRED_NUMPY_TOKENS = ["np.array"]


def _method_bodies(tree: ast.AST, class_name: str) -> dict:
    methods = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for body_item in node.body:
                if isinstance(body_item, ast.FunctionDef):
                    methods[body_item.name] = body_item
            break
    return methods


def _is_pass_only_method(fn_node: ast.FunctionDef) -> bool:
    body = fn_node.body
    # strip docstring
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body = body[1:]
    if not body:
        return True
    if len(body) == 1 and isinstance(body[0], ast.Pass):
        return True
    if len(body) == 1 and isinstance(body[0], ast.Return):
        val = body[0].value
        if isinstance(val, (ast.Constant, ast.Num, ast.Str)):
            return True
    return False


def _method_uses_param_names(fn_node: ast.FunctionDef) -> bool:
    param_names = {arg.arg for arg in fn_node.args.args if arg.arg != "self"}
    if not param_names:
        return True
    used_params = set()
    class ParamVisitor(ast.NodeVisitor):
        def visit_Name(self, node: ast.Name) -> None:
            if node.id in param_names:
                used_params.add(node.id)
            self.generic_visit(node)
    ParamVisitor().visit(fn_node)
    return len(used_params) > 0


def run_static_checks_nonfatal(solution_path: Optional[str]) -> Tuple[List[str], List[str]]:
    warnings: List[str] = []
    pass_only_methods: List[str] = []

    try:
        module = _load_solution_module(solution_path)
    except Exception as e:
        warnings.append(f"StaticCheck: Failed to import solution module: {repr(e)}")
        return warnings, pass_only_methods

    try:
        class_source = _get_class_source(module, "NumpyArrayAnalyzer", solution_path)
    except Exception as e:
        warnings.append(f"StaticCheck: Could not load NumpyArrayAnalyzer: {repr(e)}")
        return warnings, pass_only_methods

    if "np." not in class_source:
        warnings.append("StaticCheck: No 'np.' usage detected; NumPy appears unused.")

    missing_tokens = [tok for tok in REQUIRED_NUMPY_TOKENS if tok not in class_source]
    if missing_tokens:
        warnings.append(f"StaticCheck: Missing expected NumPy usage tokens: {', '.join(missing_tokens)}")

    try:
        tree = ast.parse(class_source)
    except SyntaxError as e:
        warnings.append(f"StaticCheck: Syntax error while parsing NumpyArrayAnalyzer: {repr(e)}")
        return warnings, pass_only_methods

    methods = _method_bodies(tree, "NumpyArrayAnalyzer")

    for name, fn in methods.items():
        if _is_pass_only_method(fn):
            pass_only_methods.append(name)

    unused_params = [name for name, fn in methods.items() if not _method_uses_param_names(fn)]
    if unused_params:
        warnings.append(
            "StaticCheck: The following methods do not use any of their parameters "
            f"(possible hardcoded logic): {', '.join(unused_params)}"
        )

    return warnings, pass_only_methods


def run_random_sanity_checks(analyzer) -> set:
    failing = set()
    try:
        arr = analyzer.create_order_array([1, 2, 3])
        if not np.array_equal(arr, np.array([1.0, 2.0, 3.0])):
            failing.add("create_order_array")
    except Exception:
        failing.add("create_order_array")

    try:
        changes = np.array([1.0, 3.0, 5.0])
        mean, std, mx = analyzer.compute_volatility(changes)
        if not (abs(mean - 3.0) < 1e-6 and abs(std - 2.0) < 1e-6 and abs(mx - 5.0) < 1e-6):
            failing.add("compute_volatility")
    except Exception:
        failing.add("compute_volatility")

    try:
        arr = np.array([0.0, 5.0, 10.0])
        norm = analyzer.normalize_array(arr)
        expected = np.array([0.0, 0.5, 1.0])
        if not np.allclose(norm, expected):
            failing.add("normalize_array")
    except Exception:
        failing.add("normalize_array")

    return failing


# -----------------------
# Test case functions (matrix tests removed)
# -----------------------
def case_1_create_order_array(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = analyzer.create_order_array([120.5, 250.0, 75.3, 99.99])
    expected = np.array([120.5, 250.0, 75.3, 99.99])
    passed = np.array_equal(arr, expected)
    return passed, "create_order_array builds correct float array.", str(expected), str(arr)


def case_2_validate_order_array_true(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([10.0, 20.0, 0.0])
    result = analyzer.validate_order_array(arr)
    passed = result is True
    return passed, "validate_order_array returns True for non-negative, non-empty array.", "True", str(result)


def case_3_validate_order_array_false(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([10.0, -5.0])
    result = analyzer.validate_order_array(arr)
    passed = result is False
    return passed, "validate_order_array returns False if any value is negative.", "False", str(result)


def case_4_apply_discount(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([100.0, 200.0, 300.0])
    out = analyzer.apply_discount(arr)
    expected = np.array([100.0, 180.0, 270.0])
    passed = np.allclose(out, expected)
    return passed, "apply_discount applies 10% discount for values >=150.", str(expected), str(out)


def case_5_format_order_amounts(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([100.0, 250.5])
    out = analyzer.format_order_amounts(arr)
    expected = np.array(["$100.00", "$250.50"], dtype=object)
    passed = np.array_equal(out, expected)
    return passed, "format_order_amounts formats currency correctly.", str(list(expected)), str(list(out))


def case_6_compute_order_summary(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([120.5, 250.0, 75.3, 99.99])
    total, avg, mx = analyzer.compute_order_summary(arr)
    expected_total = 120.5 + 250.0 + 75.3 + 99.99
    expected_avg = expected_total / 4
    expected_max = 250.0
    passed = (abs(total - expected_total) < 1e-6 and abs(avg - expected_avg) < 1e-6 and abs(mx - expected_max) < 1e-6)
    return passed, "compute_order_summary returns (sum, mean, max) correctly.", f"({expected_total}, {expected_avg}, {expected_max})", f"({total}, {avg}, {mx})"


def case_7_flag_high_value_orders(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([100.0, 200.0, 150.0])
    out = analyzer.flag_high_value_orders(arr, threshold=150.0)
    expected = np.array(["Normal", "High", "High"], dtype=object)
    passed = np.array_equal(out, expected)
    return passed, "flag_high_value_orders flags >=150 as High.", str(list(expected)), str(list(out))


def case_8_create_stock_array(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = analyzer.create_stock_array([2.5, -1.2, 0.8])
    expected = np.array([2.5, -1.2, 0.8])
    passed = np.array_equal(arr, expected)
    return passed, "create_stock_array builds correct float array.", str(expected), str(arr)


def case_9_validate_stock_array(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([5.0, -3.0, 9.9])
    result = analyzer.validate_stock_array(arr)
    passed = result is True
    return passed, "validate_stock_array returns True for values within [-10,10].", "True", str(result)


def case_10_validate_stock_array_invalid(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([10.0, 70.0])
    result = analyzer.validate_stock_array(arr)
    passed = result is False
    return passed, "validate_stock_array returns False for out-of-range values.", "False", str(result)


def case_11_compute_volatility(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([1.0, 3.0, 5.0])
    mean, std, mx = analyzer.compute_volatility(arr)
    passed = abs(mean - 3.0) < 1e-6 and abs(std - 2.0) < 1e-6 and abs(mx - 5.0) < 1e-6
    return passed, "compute_volatility returns (mean=3, std=2, max=5) for [1,3,5].", str((3.0, 2.0, 5.0)), f"({mean}, {std}, {mx})"


def case_12_flag_volatile_stocks(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([0.5, 3.0, 7.0])
    out = analyzer.flag_volatile_stocks(arr)
    expected = np.array(["Stable", "Moderate Risk", "High Risk"], dtype=object)
    passed = np.array_equal(out, expected)
    return passed, "flag_volatile_stocks categorizes correctly by magnitude.", str(list(expected)), str(list(out))


def case_13_longest_loss_streak(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([-1.0, -0.5, -2.0, 1.0, -0.1, -0.2])
    result = analyzer.longest_loss_streak(arr)
    expected = 3
    passed = result == expected
    return passed, "longest_loss_streak finds longest run of negatives.", str(expected), str(result)


def case_14_format_stock_report(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([1.2345, -5.6789])
    out = analyzer.format_stock_report(arr)
    expected = np.array(["1.23%", "-5.68%"], dtype=object)
    passed = np.array_equal(out, expected)
    return passed, "format_stock_report formats percentages to 2 decimals.", str(list(expected)), str(list(out))


def case_15_create_sequential_array(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = analyzer.create_sequential_array(1, 6, 1)
    expected = np.array([1., 2., 3., 4., 5.])
    passed = np.array_equal(arr, expected)
    return passed, "create_sequential_array uses np.arange correctly.", str(expected), str(arr)


def case_16_compute_elementwise_square(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([1, 2, 3])
    out = analyzer.compute_elementwise_square(arr)
    expected = np.array([1, 4, 9])
    passed = np.array_equal(out, expected)
    return passed, "compute_elementwise_square squares each element.", str(expected), str(out)


def case_17_compute_statistics(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([1.0, 2.0, 3.0])
    total, mean, mn, mx = analyzer.compute_statistics(arr)
    passed = (abs(total - 6.0) < 1e-6 and abs(mean - 2.0) < 1e-6 and abs(mn - 1.0) < 1e-6 and abs(mx - 3.0) < 1e-6)
    return passed, "compute_statistics returns (sum, mean, min, max).", str((6.0, 2.0, 1.0, 3.0)), f"({total}, {mean}, {mn}, {mx})"


def case_18_filter_above_threshold(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([1.0, 3.5, 2.0, 5.0])
    out = analyzer.filter_above_threshold(arr, 2.5)
    expected = np.array([3.5, 5.0])
    passed = np.array_equal(out, expected)
    return passed, "filter_above_threshold keeps values > threshold.", str(expected), str(out)


def case_19_replace_negatives_with_zero(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([-1.0, 0.0, 2.0])
    out = analyzer.replace_negatives_with_zero(arr)
    expected = np.array([0.0, 0.0, 2.0])
    passed = np.array_equal(out, expected)
    return passed, "replace_negatives_with_zero sets negatives to 0.", str(expected), str(out)


def case_20_normalize_array(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([0.0, 5.0, 10.0])
    out = analyzer.normalize_array(arr)
    expected = np.array([0.0, 0.5, 1.0])
    passed = np.allclose(out, expected)
    return passed, "normalize_array scales values to [0,1].", str(expected), str(out)


def case_21_concatenate_arrays(analyzer: object) -> Tuple[bool, str, str, str]:
    a = np.array([1, 2])
    b = np.array([3, 4])
    out = analyzer.concatenate_arrays(a, b)
    expected = np.array([1, 2, 3, 4])
    passed = np.array_equal(out, expected)
    return passed, "concatenate_arrays concatenates two arrays.", str(expected), str(out)


def case_22_compute_dot_product(analyzer: object) -> Tuple[bool, str, str, str]:
    a = np.array([1, 2, 3])
    b = np.array([4, 5, 6])
    result = analyzer.compute_dot_product(a, b)
    expected = 1*4 + 2*5 + 3*6
    passed = abs(result - expected) < 1e-6
    return passed, "compute_dot_product returns correct dot product.", str(expected), str(result)


def case_23_unique_sort_nonzero(analyzer: object) -> Tuple[bool, str, str, str]:
    arr = np.array([0, 1, 2, 2, 0, 3])
    unique_vals = analyzer.get_unique_values(arr)
    sorted_vals = analyzer.sort_array(unique_vals)
    nonzero_count = analyzer.count_nonzero(arr)
    expected_unique_sorted = np.array([0, 1, 2, 3])
    expected_nonzero = 4
    passed = np.array_equal(sorted_vals, expected_unique_sorted) and nonzero_count == expected_nonzero
    exp_str = f"unique={expected_unique_sorted}, nonzero={expected_nonzero}"
    got_str = f"unique={sorted_vals}, nonzero={nonzero_count}"
    return passed, "get_unique_values, sort_array, count_nonzero work together.", exp_str, got_str


def test_student_code(solution_path: Optional[str] = None) -> None:
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = f"=== {ASSESSMENT_NAME} Test Run at {timestamp} ==="
    _log_line(header)

    warnings, pass_only_methods = run_static_checks_nonfatal(solution_path)
    if warnings:
        for w in warnings:
            _log_line(f"StaticCheck Warning: {w}")
    else:
        _log_line("StaticCheck Passed: No immediate issues detected.")

    if pass_only_methods:
        _log_line("Note: The following methods appear to be pass-only or constant-return (their tests will fail): " + ", ".join(pass_only_methods))

    try:
        module = _load_solution_module(solution_path)
        NumpyArrayAnalyzer = getattr(module, "NumpyArrayAnalyzer")
    except Exception as e:
        _log_line(f"Error: Could not load NumpyArrayAnalyzer class: {repr(e)}")
        return

    analyzer = NumpyArrayAnalyzer()

    random_failures = run_random_sanity_checks(analyzer)
    if random_failures:
        _log_line("RandomSanity Warning: Randomized logic mismatches detected for: " + ", ".join(sorted(random_failures)))

    tests = [
        case_1_create_order_array,
        case_2_validate_order_array_true,
        case_3_validate_order_array_false,
        case_4_apply_discount,
        case_5_format_order_amounts,
        case_6_compute_order_summary,
        case_7_flag_high_value_orders,
        case_8_create_stock_array,
        case_9_validate_stock_array,
        case_10_validate_stock_array_invalid,
        case_11_compute_volatility,
        case_12_flag_volatile_stocks,
        case_13_longest_loss_streak,
        case_14_format_stock_report,
        case_15_create_sequential_array,
        case_16_compute_elementwise_square,
        case_17_compute_statistics,
        case_18_filter_above_threshold,
        case_19_replace_negatives_with_zero,
        case_20_normalize_array,
        case_21_concatenate_arrays,
        case_22_compute_dot_product,
        case_23_unique_sort_nonzero,
    ]

    method_names = [
        "create_order_array",
        "validate_order_array",
        "validate_order_array",
        "apply_discount",
        "format_order_amounts",
        "compute_order_summary",
        "flag_high_value_orders",
        "create_stock_array",
        "validate_stock_array",
        "validate_stock_array",
        "compute_volatility",
        "flag_volatile_stocks",
        "longest_loss_streak",
        "format_stock_report",
        "create_sequential_array",
        "compute_elementwise_square",
        "compute_statistics",
        "filter_above_threshold",
        "replace_negatives_with_zero",
        "normalize_array",
        "concatenate_arrays",
        "compute_dot_product",
        "get_unique_values",
    ]

    for i, fn in enumerate(tests, start=1):
        try:
            target_method = method_names[i - 1] if i - 1 < len(method_names) else None
            if target_method and target_method in pass_only_methods:
                passed = False
                desc = f"{fn.__name__} could not run because the implementation for '{target_method}' appears to be pass-only or a constant return."
                exp = "Functional implementation"
                got = "pass-only / constant-return placeholder"
            else:
                passed, desc, exp, got = fn(analyzer)
        except Exception as e:
            passed = False
            desc = f"{fn.__name__} raised an exception"
            exp = "No exception"
            got = f"Exception: {repr(e)}"

        if passed:
            _log_line(f"Visible Test Case {i} Passed: {desc}")
        else:
            _log_line(f"Visible Test Case {i} Failed: {desc} | Expected={exp} | Got={got}")


if __name__ == "__main__":
    test_student_code()

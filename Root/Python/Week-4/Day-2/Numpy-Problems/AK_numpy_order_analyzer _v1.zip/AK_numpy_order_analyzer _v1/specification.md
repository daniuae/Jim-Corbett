# NumPy Array Analysis — Specification

## Overview
Implement the `NumpyArrayAnalyzer` class providing array utilities for orders and stock analyses plus general NumPy practice functions. Two matrix-related functions and tests were intentionally removed for this assessment: `reshape_to_matrix` and `transpose_matrix`.

Do not include top-level executable code in `solution.py`.

## Class
`class NumpyArrayAnalyzer:`

## Required public instance methods (signatures)

### Order-related (6)
- `def create_order_array(self, amounts: List[float]) -> np.ndarray`
  - Create float NumPy array from `amounts`.

- `def validate_order_array(self, order_array: np.ndarray) -> bool`
  - Return `True` if `order_array` is non-empty and all values are `>= 0`.

- `def apply_discount(self, order_array: np.ndarray) -> np.ndarray`
  - Apply 10% discount to elements `>= 150.0` and return transformed array.

- `def format_order_amounts(self, order_array: np.ndarray) -> np.ndarray`
  - Return `dtype=object` array of strings formatted as currency (e.g. `"$100.00"`).

- `def compute_order_summary(self, order_array: np.ndarray) -> Tuple[float,float,float]`
  - Return `(total, average, max)`.

- `def flag_high_value_orders(self, order_array: np.ndarray, threshold: float = 150.0) -> np.ndarray`
  - Return labels `"High"` / `"Normal"` according to threshold (`>= threshold` labelled `"High"`).

### Stock-related (7)
- `def create_stock_array(self, changes: List[float]) -> np.ndarray`
- `def validate_stock_array(self, changes: np.ndarray) -> bool`
  - Values expected within [-10, 10].

- `def compute_volatility(self, changes: np.ndarray) -> Tuple[float,float,float]`
  - Return `(mean, std(ddof=1 if n>1 else 0), max)`.

- `def flag_volatile_stocks(self, changes: np.ndarray) -> np.ndarray`
  - Categories: `Stable` (<2), `Moderate Risk` (2-5 inclusive), `High Risk` (>5).

- `def longest_loss_streak(self, changes: np.ndarray) -> int`
  - Longest consecutive negative-run length.

- `def format_stock_report(self, changes: np.ndarray) -> np.ndarray`
  - Return strings like `"1.23%"`.

### Additional NumPy practice (10)
- `def create_sequential_array(self, start: int, stop: int, step: int=1) -> np.ndarray`
- `def compute_elementwise_square(self, arr: np.ndarray) -> np.ndarray`
- `def compute_statistics(self, arr: np.ndarray) -> Tuple[float, float, float, float]`
  - `(sum, mean, min, max)`

- `def filter_above_threshold(self, arr: np.ndarray, threshold: float) -> np.ndarray`
- `def replace_negatives_with_zero(self, arr: np.ndarray) -> np.ndarray`
- `def normalize_array(self, arr: np.ndarray) -> np.ndarray`
  - Normalize to `[0,1]`. If all elements equal, return zeros array.

- `def concatenate_arrays(self, a: np.ndarray, b: np.ndarray) -> np.ndarray`
- `def compute_dot_product(self, a: np.ndarray, b: np.ndarray) -> float`
- `def get_unique_values(self, arr: np.ndarray) -> np.ndarray`
- `def sort_array(self, arr: np.ndarray) -> np.ndarray`
- `def count_nonzero(self, arr: np.ndarray) -> int`

> Note: Although tests will detect methods implemented as `pass` or returning constants, static checks are non-fatal. If a method is detected pass-only/constant-return, its corresponding visible test will be marked **Failed** with a clear reason indicating it was a placeholder.

## Static-check rules (informational)
- The grader looks for usage of `np.` tokens; missing tokens will be logged as warnings.
- Methods that do not reference their parameters may be flagged as suspicious (warning).

## Testing behavior
- Tests are deterministic (no hidden randomness).
- The driver writes results to `test_report.log`.
- Students should not change method names or signatures.

## Deliverables
- `solution.py` containing the `NumpyArrayAnalyzer` class implementing required methods.
- `driver.py` (this file) will be used to grade students.
- `test_report.log` will be produced by the driver.

